#ifndef _MYBOOL_H_

#define _MYBOOL_H_
#define true 1
#define false 0

typedef int mybool;

#endif
