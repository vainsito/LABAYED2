
unsigned int array_from_file(int array[],
                             unsigned int max_size,
                             const char *filepath) {

    FILE *fichero = fopen(filepath,"rt");

    unsigned int size;
    fscanf(fichero,"%u",&size); // es literalmente el primero que lee

    if(size>max_size){
        printf("Error in size format\n");
        exit(EXIT_FAILURE);
    }

    for(unsigned int i=0 ; i<size; i++){
        fscanf(fichero,"%d",&array[i]);
        if ( i == size - 1 && (feof(fichero))){
            printf("Error in file format\n");
            exit(EXIT_FAILURE);
        
    }}

    fclose(fichero);

    return size;
}

void array_dump(int a[], unsigned int length){
    
    printf("[");
    for(unsigned int i = 0; i<length ; i++){
        printf(" %d",a[i]);
        if(i<length - 1){
            printf(",");
        }
    }
    
    printf("]\n");

}
